export class Product {
  constructor(
    public pname: string,
    public images: string,
    public price: number
  ) {}
}
